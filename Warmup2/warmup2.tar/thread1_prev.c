#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <string.h>
#include <time.h>
#include <signal.h>
#include <math.h>
#include <unistd.h>
#include <errno.h>
#include "cs402.h"
#include "my402list.h"
#include "shared.h"
typedef struct packet_struct
	{
		int token_id;
		int num_of_tokens_reqd;
		double enter_timeq1;
		double enter_timeq2;
		double exit_timeq1;
		double exit_timeq2;
		double inter_arrival_time;
		double q1_service;
		double service_time;
		double system_exit_time;
	}packet;
struct timeval tv;
char *pass_arg1;
void *handler();
void interrupt();
int pass_arg2;
double packet_inter_arrival_time=0;
int tokens_drop=0;
int ctrl_signl=1;
int packets_serviced;
int packets_drop=0;
double avg_time_in_Q1=0;
double q2_packet_time=0.0;
double q1_packet_time=0;
double avg_time_in_Q2=0;
double sum_of_sq=0.0;
double avg_packet_in_S=0;
double avg_time_in_system=0.0;
double total_system_time=0.0;
double token_drop_probability;
double packet_drop_probability;
FILE *fp=NULL;
int read_count=0;
int count_serviced_packets=0;
double avg_packet_service_time=0;
double total_service_time=0;
double total_inter_arrival_time=0;
double total_emulation_time=1;
int record_point=0;
int file_input=0;
int visit_chk=0;
int return_val;
double avg_packet_inter_arrival_time;
int visit_count=0;
int chk_packet=0;
int x;
char input[4000];
double start_time=0;
double standard_deviation=0;
int chk_counter=0;
int count_token=0;
int counter=0;
void * file_read(char*, int);
void *pthreadCreate(void*);
void *pthreadService(void*);
void *token_bucket(void*);
My402List *new_list;
My402List *service_list;
int num_of_tokens=10;
int service_variable=0;
int count_current_packet=0;
packet *p;
int tid=1;
int tokens_reqd=3;

pthread_t threads1;
pthread_t threads2;
pthread_t threads3;
pthread_t threads4;

pthread_mutex_t m=PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t q2_not_empty=PTHREAD_COND_INITIALIZER;

int num_of_packets=20;
char *store_tokens_reqd[1000];
float lambda=0.5;
float mu=0.35;
float r=1.5;
float time_enter;
double time_service=9253;
int add_tokens=0;
int alpha=0;
int set_file_input=0;
//sigset_t new;s
//pthread_t user_threadID;
sigset_t action;
int main(int argc, char *argv[])
	{				
		//printf("Value argc=%d\n",argc);		
		int comand_i=1;
		if(argc<1)
		{	
			//	printf("Deterministic mode");
		}
		else
		{
			while(argc!=1)
			{	
			//printf("**********%s\n",argv[comand_i]);		
			if(strcmp(argv[comand_i],"-t")==0)
					{
						file_input=1;						
						//printf("tfile detected/..\n");					
						//printf("read success");
						set_file_input=1;
						pass_arg1=argv[++comand_i];
						pass_arg2=comand_i;
						comand_i++;
						//file_read(pass_arg1,pass_arg2);
						argc--;
						argc--;
					}
			else if(strcmp(argv[comand_i],"-n")==0)
					{
						//printf("n detected\n");
						comand_i++;
						//printf("num%d\n",atoi(argv[comand_i]));
						num_of_packets=atoi(argv[comand_i]);
						comand_i++;
						argc--;
						argc--;
					}
			else if(strcmp(argv[comand_i],"-P")==0)
					{
						//printf("P detected\n");
						comand_i++;
						//printf("P%d\n",atoi(argv[comand_i]));
						tokens_reqd=atoi(argv[comand_i]);
						comand_i++;	
						argc--;	
						argc--;	
					}
			else if(strcmp(argv[comand_i],"-B")==0) 
					{
						//printf("B detected\n");
						comand_i++;
						//printf("B%d\n",atoi(argv[comand_i]));
						num_of_tokens=atoi(argv[comand_i]);
						comand_i++;
						argc--;
						argc--;
					}	
			else if(strcmp(argv[comand_i],"-r")==0)
					{	
						//printf("r detected\n");
						comand_i++;
						//printf("r%f\n",atof(argv[comand_i]));
						r=atof(argv[comand_i]);
						comand_i++;
						argc--;
						argc--;
					}
			else if(strcmp(argv[comand_i],"-lambda")==0)
					{	
						//printf("lambda detected\n");
						comand_i++;
						//printf("lambda%f\n",atof(argv[comand_i]));
						lambda=atof(argv[comand_i]);
						comand_i++;
						argc--;
						argc--;
					}
			else if(strcmp(argv[comand_i],"-mu")==0)
					{	
						//printf("mu detected\n");
						comand_i++;
						//printf("mu%f\n",atof(argv[comand_i]));
						mu=atof(argv[comand_i]);
						comand_i++;
						argc--;
						argc--;
					}
			else
					{
						fprintf(stderr,"Invalid Input");
						exit(0);
					}
			}
			
						if(file_input==0)
						{
						printf("Emulation Parameters\n");
						printf("lambda%f\n",lambda);
						printf("mu%f\n",mu);
						printf("r%f\n",r);
						printf("B%d\n",num_of_tokens);
						printf("P%d\n",tokens_reqd);
						printf("number to arrive%d\n",num_of_packets);
					}
		}
		//int i;
		time_service=(1/mu)*1000;
		sigemptyset(&action);
		sigaddset(&action, SIGINT);
		pthread_sigmask(SIG_BLOCK,&action,NULL);
		pthread_create(&threads4, NULL, handler, argv[1]);
		new_list = (My402List*)malloc(sizeof(My402List));
		My402ListInit(new_list);
		service_list = (My402List*)malloc(sizeof(My402List));
		My402ListInit(service_list);
		if(service_list==NULL)
			{
				fprintf(stderr,"Error allocating memory to my402list");
				exit(0);
			}	
			return_val=pthread_create(&threads1,NULL,(void *)token_bucket,NULL);
			if(return_val==0)
			{
				//printf("Token inserted...Success \n");	
			}
			return_val=pthread_create(&threads2,NULL,(void *)pthreadCreate,NULL);
			if(return_val==0)
			{
				//printf("Thread creation success..append \n");	
			}
			return_val=pthread_create(&threads3,NULL,(void *)pthreadService,NULL);
			if(return_val==0)
			{
				//printf("Thread creation success..service \n");	
			}
				
			pthread_join(threads1, NULL);	
			//printf("thread1 destroyed...\n");
			pthread_join(threads2, NULL);
			//printf("thread2 destroyed...\n");
			pthread_join(threads3, NULL);	  
			//printf("thread3 destroyed...\n");
			pthread_join(threads4, NULL);
			//printf("threads 4 destroyed");
			
			gettimeofday(&tv,NULL);	
			total_emulation_time=((tv.tv_sec)*1000.0+(tv.tv_usec)/1000.0)-start_time;
 
			//printf("--------------------STATISTICS--------------------------\n");
			
			if(count_current_packet==0)
			printf("\tAvg packet inter-arrival time=NA as there are no packets present\n");			
			else
			{
			avg_packet_inter_arrival_time=(total_inter_arrival_time)/(count_current_packet);
			printf("\tAvg packet inter-arrival time=%.6gs\n",(avg_packet_inter_arrival_time)/1000.0);
			}
			if(count_serviced_packets==0)
			printf("\tAvg packet service time=NA as there are no serviced packets present\n");			
			else
			{
			avg_packet_service_time=(total_service_time)/(count_serviced_packets);
			printf("\tAvg packet service time=%.6gs\n",(avg_packet_service_time)/1000.0);
			}
			if(total_emulation_time==0)
			printf("\tAvg no. of packets in Q1=NA as the total emulation time is zero\n");
			else
			{
			avg_time_in_Q1=(q1_packet_time)/(total_emulation_time);
			printf("\tAvg no. of packets in Q1=%.6g packets\n",(avg_time_in_Q1));
			}
			if(total_emulation_time==0)
			printf("\tAvg no. of packets in Q2=NA as total emulation time is zero\n");			
			else
			{
			avg_time_in_Q2=(q2_packet_time)/(total_emulation_time);
			printf("\tAvg no. of packets in Q2=%.6g packets\n",avg_time_in_Q2);
			}
			if(total_emulation_time==0)
			printf("\tAvg no. of packets in S=NA as total emulation time is zero\n");
			else
			{
			avg_packet_in_S=(total_service_time)/(total_emulation_time);
			printf("\tAvg no. of packets at S=%.6g packets\n",avg_packet_in_S);
			}
			if(packets_serviced==0)
			printf("\tAvg no. of packets in S=NA as there are no serviced packets present\n");
			else
			{
			avg_time_in_system=(total_system_time)/(packets_serviced);
			printf("\tAvg time a packet spent in system=%.6gs\n",avg_time_in_system/1000);	
			}
			if(packets_serviced==0)
			printf("\tStandard deviation for time spent in system=NA as there are no serviced packets present\n");
			else
			{
			standard_deviation=sqrt((((sum_of_sq)/packets_serviced)/1000000)-pow((total_system_time/packets_serviced)/1000,2));
			printf("\tStandard deviation for time spent in system=%.6g\n",standard_deviation);
			}
			if(count_token==0)
			printf("\ttoken drop probability=NA as there are no tokens present\n");
			else
			{
			token_drop_probability=(tokens_drop)/(count_token);
			printf("\ttoken drop probability=%.6g\n",token_drop_probability);
			}
			if(count_token==0)
			printf("\tpacket drop probability=NA as there are no tokens present\n");
			else
			{
			packet_drop_probability=(packets_drop)/(count_token);
			printf("\tpacket drop probability=%.6g\n",packet_drop_probability);
			}
			free(new_list);
			free(service_list);
	return (0);
	}
void Traverse(My402List *new_list)
	{
		My402ListElem *elem;
		elem=My402ListFirst(new_list);
		if(elem==NULL)
			{	
			//printf("list empty..\n");		
			}
		for(elem=My402ListFirst(new_list);elem!= NULL;elem=My402ListNext(new_list,elem))
			{
			printf("\n");			
			packet *packet_elem = (packet *)(elem->obj);						
			printf("elems1...%d  ",(packet_elem->token_id));
			printf("elems2...%d  ",(packet_elem->num_of_tokens_reqd));
			printf("elems3...%lf  ",(packet_elem->enter_timeq1));			
			printf("elems4...%lf  ",(packet_elem->exit_timeq1));
			printf("elems5...%lf  ",(packet_elem->enter_timeq2));
			printf("elems6...%lf  ",(packet_elem->exit_timeq2));
			//q1_packet_time=q1_packet_time+((packet_elem->exit_timeq1)-(packet_elem->enter_timeq1));		
			printf("\n");
			}
	}
void *pthreadCreate(void* sample)
	{								
				//printf("pThreadCreate Created ...\n");
				double prev_inter_arrival_time=0;
				double cur = 0.0;	
				while(TRUE)
				{					
					if(file_input==1)
						{	
							//printf("Reading file...\n");				
							file_read(pass_arg1,pass_arg2);
							//printf("file read...\n");
						}
						
					gettimeofday(&tv, NULL);	
					cur = (tv.tv_sec)*1000.0+(tv.tv_usec)/1000.0-start_time;
					//printf("Operation time = %lf\n", cur - prev_inter_arrival_time);
					//printf("Entering packet thread\n");
					int diff=(cur - prev_inter_arrival_time)*1000;
					if(file_input==1)
					{				
					int create_sleep=((1/lambda)*1000.0);
					//printf("create sleep =%d\n",create_sleep);
					//printf("Sleeping for %ld ms\n", (create_sleep-diff)/1000);
					usleep(create_sleep-diff);
					}
					else
					{
						if((1/lambda)<=10)
						{
						int create_sleep=((1/lambda)*1000*1000);
						//printf("Sleeping for %ld ms\n", (create_sleep-diff)/1000);
						usleep(create_sleep-diff);
						}
						else
						{
						int create_sleep=(10*1000*1000);
						//printf("Sleeping for %ld ms\n", (create_sleep-diff)/1000);
						usleep(create_sleep-diff);
						}
					}
					pthread_mutex_lock(&m);
					if(count_current_packet>=num_of_packets )
						{
					//printf("************packet-count..%d",count_current_packet);
					//printf("Thread exiting create\n");
					pthread_mutex_unlock(&m);
					pthread_exit(0);
						}					
					if(chk_packet!=num_of_packets)
						{						
						count_current_packet++;
						chk_packet++;	
						//printf("Tokens reqrd = %d\n",tokens_reqd);
						packet *p2=(packet*) malloc(sizeof(packet));
						if(p2==NULL)
							fprintf(stderr,"Error allocating memory to argument\n");				
						p2->token_id=tid;
						p2->num_of_tokens_reqd=tokens_reqd;
						p2->service_time=time_service;
						if(time_service>10000 && file_input!=1)
						p2->service_time=10000;
						gettimeofday(&tv,NULL);	
						double temp_time=((tv.tv_sec)*1000.0+(tv.tv_usec)/1000.0)-start_time;
						tid++;
						
						p2->inter_arrival_time=temp_time-prev_inter_arrival_time;
						total_inter_arrival_time=total_inter_arrival_time+p2->inter_arrival_time;

						prev_inter_arrival_time=temp_time;
						//int create_sleep=((1/lambda)*1000*1000);
						//pthread_mutex_unlock(&m);
						//usleep(create_sleep);
						//pthread_mutex_lock(&m);
						//printf("************p%d arrives",p2->token_id);
						printf("%012.3lfms:p%d arrives, needs %d, inter-arrival time=%.3fms\n",temp_time,p2->token_id,p2->num_of_tokens_reqd,p2->inter_arrival_time);
						if((p2->num_of_tokens_reqd)>num_of_tokens)
						{
							packets_drop++;
							gettimeofday(&tv,NULL);	
							double packet_time=((tv.tv_sec*1000.0)+(tv.tv_usec)/1000.0)-start_time;	
							printf("%012.3lfms: packet p%d arrives,needs %d tokens, dropped\n",packet_time,(p2->token_id),(p2->num_of_tokens_reqd));
							free(p2);
							if(count_current_packet >= num_of_packets)
							{
								if(My402ListLength(new_list) <= 0 && My402ListLength(service_list) <= 0)
								{
									pthread_cond_broadcast(&q2_not_empty);
									pthread_mutex_unlock(&m);
									return NULL;
								}
							}
						}
						else
						{		
												
							My402ListAppend(new_list,p2);
							gettimeofday(&tv,NULL);	
							p2->enter_timeq1=((tv.tv_sec)*1000.0+(tv.tv_usec)/1000.0)-start_time;
							printf("%012.3lfms:p%d enters Q1\n",p2->enter_timeq1,p2->token_id);
						}
						//My402ListElem *temp=My402ListFirst(new_list);
						packet *p3= (packet *)malloc(sizeof(packet));
						p3 = (packet*)(My402ListFirst(new_list)->obj);
						//printf("Q1 Waiting\n");
						if(add_tokens>=(p3->num_of_tokens_reqd))
						{
							add_tokens=add_tokens-(p3->num_of_tokens_reqd);
							My402ListUnlink(new_list,My402ListFirst(new_list));				        
							gettimeofday(&tv,NULL);
							p3->exit_timeq1=((tv.tv_sec*1000.0)+(tv.tv_usec)/1000.0)-start_time;
							q1_packet_time += (p3->exit_timeq1)-(p3->enter_timeq1);
							printf("%012.3lfms:p%d leaves Q1, time in Q1=%.6f, token bucket now has %d tokens\n",p3->exit_timeq1,p3->token_id,(p3->exit_timeq1)-(p3->enter_timeq1),add_tokens);
							gettimeofday(&tv,NULL);	
							p3->enter_timeq2=((tv.tv_sec*1000.0)+(tv.tv_usec)/1000.0)-start_time;	
							printf("%012.3lfms:p%d enters Q2\n",p3->enter_timeq2,p3->token_id);
							My402ListAppend(service_list,(void *)p3);	
							gettimeofday(&tv,NULL);	
							p3->q1_service=((tv.tv_sec)*1000.0+(tv.tv_usec)/1000.0)-start_time;
							//p3->inter_arrival_time=packet_inter_arrival_time;
							//total_inter_arrival_time=total_inter_arrival_time+packet_inter_arrival_time;
							/*if((packet_inter_arrival_time)>(p3->q1_service))
							{
									double diff1=(p3->inter_arrival_time)-(p3->q1_service);
									int diff2=(int)(diff1);
									pthread_mutex_unlock(&m);
									//printf("Sleeping for...%d",diff2);
									usleep(diff2);
									pthread_mutex_lock(&m);
							}
							else
							{
										//printf("No wait...time exceeded");
									usleep(0);
							}
							*/
							
						}
						//printf("Checking for Q2\n");
						if(My402ListLength(service_list)>0)
						{
								//printf("pthreadService has element\n");						
								pthread_cond_signal(&q2_not_empty);
						}
				}
				pthread_mutex_unlock(&m);
			}	
			return NULL;	
	}
void *token_bucket(void* val)
{
		//printf("Token bucket thread entered..\n");
		double temp_val1,temp_val2,temp_val3;
		My402ListElem *elem=NULL;
		if(chk_counter==0)
		{
						gettimeofday(&tv,NULL);	
						temp_val1=(tv.tv_sec)*1000.0+(tv.tv_usec)/1000.0;
						temp_val2=temp_val1;
						start_time=temp_val2;
						temp_val3=temp_val1-temp_val2;
						//printf("tsfile%s",lambda);
						printf("\n%012.3lfms: Simulation Begins \n",(temp_val3));
						chk_counter++;
		}
		double token_prev_time=0.0;
		double cur_time=0.0;
		while(TRUE)
			{
			//return condition
				gettimeofday(&tv,NULL);
				cur_time = (tv.tv_sec)*1000.0+(tv.tv_usec)/1000.0-start_time;
				int bucket_sleep=((1/r)*1000*1000);
				if((1/r)>10)
				bucket_sleep=10*1000*1000;
				int diff_tok=cur_time-token_prev_time;
				//printf("Sleeping for %d\n",bucket_sleep);
				if((bucket_sleep-diff_tok)<0)
				usleep(0);
				else
				usleep(bucket_sleep-diff_tok);
				pthread_mutex_lock(&m);
				if(count_current_packet>=num_of_packets && My402ListLength(new_list)==0)
				{
					//printf("Token Thread exiting bucket\n");
					pthread_mutex_unlock(&m);
					pthread_exit(0);
				}
			//tokens to be added for packets
			
					//pthread_mutex_lock(&m);
					
					  count_token++;
					  gettimeofday(&tv,NULL);
					  token_prev_time = (tv.tv_sec)*1000.0+(tv.tv_usec)/1000.0-start_time;
					if(add_tokens<num_of_tokens)		
					{
						
						add_tokens++;
						//store3=temp_val1-temp_val2;	
							gettimeofday(&tv,NULL);	
							temp_val1=(tv.tv_sec)*1000.0+(tv.tv_usec)/1000.0-start_time;
							printf("%012.3lfms: token t%d arrives, token bucket now has %d tokens	\n",temp_val1,count_token,add_tokens);
							
						
						if(My402ListLength(new_list)!=0)
						{
								elem=My402ListFirst(new_list);
								
									packet *bucket_elem = (packet *)(elem->obj);				
										//printf("***reqd...%d\n",(bucket_elem->num_of_tokens_reqd));
										//printf("**add_tokens%d\n",add_tokens);
									if(add_tokens>=(bucket_elem->num_of_tokens_reqd))
									{			
										//printf("Moving Q1 to Q2\n");
											//printf("%fms: token t%d arrives, token bucket now has %d tokens	\n",store3,count_token,add_tokens);
											//count_token++;
											add_tokens=add_tokens-bucket_elem->num_of_tokens_reqd;
											My402ListAppend(service_list,bucket_elem);
						
											My402ListUnlink(new_list, (void *)elem);
											gettimeofday(&tv,NULL);	
											double tempp=(tv.tv_sec)*1000.0+(tv.tv_usec)/1000.0-start_time;
											bucket_elem->exit_timeq1=tempp;
											q1_packet_time += (bucket_elem->exit_timeq1)-(bucket_elem->enter_timeq1);
											printf("%012.3lfms:p%d leaves Q1, time in Q1=%.6f, token bucket now has %d tokens\n",bucket_elem->exit_timeq1,bucket_elem->token_id,(bucket_elem->exit_timeq1)-(bucket_elem->enter_timeq1),add_tokens);
											gettimeofday(&tv,NULL);	
											bucket_elem->enter_timeq2=((tv.tv_sec*1000.0)+(tv.tv_usec)/1000.0)-start_time;	
											printf("%012.3lfms:p%d enters Q2\n",bucket_elem->enter_timeq2,bucket_elem->token_id);
										
									}
						}
					}
					else
					{
									tokens_drop++;
									gettimeofday(&tv,NULL);	
									double tempp=(tv.tv_sec)*1000.0+(tv.tv_usec)/1000.0-start_time;
								  printf("%012.3lfms: token t%d arrives, dropped\n",tempp,(count_token));
												//printf("not enough tokens\n");
					}
					if(My402ListLength(service_list)>0)
										{			
												//printf("Signalling Q2 not empty\n");
												pthread_cond_signal(&q2_not_empty);
												//pthread_mutex_unlock(&m);	
										}
					
			pthread_mutex_unlock(&m);			
		}
	}
	void *pthreadService(void* pass_param)
	{					
			//if(My402ListLength(service_list)==0)
			//printf("service list empty\n");			
			//printf("pthreadService created..\n");
			ctrl_signl = 1;				
			while(ctrl_signl==1)
			{	

					//printf("While entered..");
					//usleep((int)(mu));				
					pthread_mutex_lock(&m);	
			if((count_current_packet>=num_of_packets && My402ListLength(new_list)==0 && My402ListLength(service_list)==0) || (My402ListLength(new_list)==0 && ctrl_signl==0 && My402ListLength(service_list)==0))
			{
					//printf("num = %d ctrl = %d\n",count_current_packet, ctrl_signl);
					//printf("Thread exiting--Service\n");
					
					pthread_mutex_unlock(&m);
							
					break;
					//pthread_exit(0);
			}	
				//printf("Sleeping for ...%d\n",(int)time_service);		
				gettimeofday(&tv,NULL);		
				if(My402ListLength(service_list)==0)
					{
						//printf("Waiting...");
						pthread_cond_wait(&q2_not_empty,&m);
						//printf("Waiting done...");					
						pthread_mutex_unlock(&m);						
					}				
				while(My402ListLength(service_list)!=0)
				{
				//printf("Servicing....\n");
				My402ListElem *temp=My402ListFirst(service_list);
				packet *p3copy=(packet *)(My402ListFirst(service_list)->obj);
				//Traverse(service_list);
				My402ListUnlink(service_list, temp);	
				gettimeofday(&tv,NULL);
				p3copy->exit_timeq2=((tv.tv_sec)*1000.0+(tv.tv_usec)/1000.0)-start_time;
				printf("%012.3lfms:p%d begin service at S, time in Q2=%.6lf\n",p3copy->exit_timeq2,p3copy->token_id,p3copy->exit_timeq2-p3copy->enter_timeq2);	
				pthread_mutex_unlock(&m);	
				usleep((int)(p3copy->service_time*1000));				
				packets_serviced++;
				//set_file_input=0;
				pthread_mutex_lock(&m);		
				gettimeofday(&tv,NULL);
				p3copy->system_exit_time=((tv.tv_sec)*1000.0+(tv.tv_usec)/1000.0)-start_time;
				total_system_time+=(p3copy->system_exit_time)-(p3copy->enter_timeq1);
				sum_of_sq+=pow((p3copy->system_exit_time-p3copy->enter_timeq1),2);
				printf("%012.3lfp%d:departs from S, service time=%.6lf, time in system=%.6lf\n",p3copy->system_exit_time,p3copy->token_id,p3copy->service_time,((p3copy->system_exit_time)-(p3copy->enter_timeq1)));
				count_serviced_packets++;
				//printf("Q2 length = %d\n", My402ListLength(service_list));
				q2_packet_time=q2_packet_time+((p3copy->exit_timeq2)-(p3copy->enter_timeq2));
				total_service_time=(total_service_time+(p3copy->system_exit_time-p3copy->exit_timeq2)); 
				free(p3copy);
				//printf("Q1-Len=%d Q2-Len=%d\n",My402ListLength(new_list),My402ListLength(service_list));
				//Traverse(service_list);
				}
		pthread_mutex_unlock(&m);						
	}
	pthread_cancel(threads4);
		return NULL;
}
void interrupt()
{					
			ctrl_signl = 0;
			pthread_mutex_lock(&m);
			My402ListUnlinkAll(new_list);
			My402ListUnlinkAll(service_list);
			//printf("Cancelling thread1\n");
			pthread_cancel(threads1);
			pthread_cancel(threads2);
			//printf("Cancelled thread1 & 2\n");
			//printf("broadcasting..");
			pthread_cond_broadcast(&q2_not_empty);
			//printf("broadcast done..");
			pthread_mutex_unlock(&m);
}
void *handler(void *argumnt)
{
			struct sigaction act;
			act.sa_flags = 0;					
			act.sa_handler=interrupt;
			sigaction(SIGINT, &act,NULL);
			pthread_sigmask(SIG_UNBLOCK, &action, NULL);
			sleep(2147483647);
			return NULL;
}
void *file_read(char *a,int val)
{															
						//printf("File read entered...");						
						//int comand_i=val;						
						char *argv;
						argv=a;			
						//printf("argv in file_read%s",argv);			
						//FILE *myfile;
						//char file_name[30];
						char *alpha_chk1;
						//char *alpha_chk2;
						alpha_chk1="[";
						//alpha_chk2="]";
						//int alpha_temp=0;
						char *store_temp=argv;
						if(strncmp((argv),alpha_chk1,1)==0)	
						{
						//printf("detected [...\n");						
						//char *file_val;
						//alpha_temp=(int)(strlen(argv));
						//char *last_char=&store_temp[alpha_temp-1];
						//printf("last char%s\n",last_char);
						store_temp[strlen(store_temp)-1]='\0';
						//printf("store_temp%s",store_temp);
						memmove(store_temp, store_temp+1, strlen(store_temp));
						//printf("store_temp%s",store_temp);
						}
						if(read_count==0)
						{
						//printf("Reading...");
						fp=fopen(store_temp,"r");
						read_count++;
						}
						if(fp==NULL)
						{
						fprintf(stderr,"No input present");
						exit(0);
						}
						else
						{
						int chk=0;
						if(counter==0)
						{
						if((fgets(input,sizeof(input),fp) ) != NULL)
						{
						sscanf(input,"%d",&num_of_packets);
						//if(set_file_input==1)
						{
						printf("\tEmulation Parameters\n");
						printf("\tr=%f\n",r);
						printf("\tB=%d\n",num_of_tokens);
						printf("\tfileName%s\n",argv);
						//printf("//////////////////////////////num_of_packets%d\n",num_of_packets);
						++counter;
						}
						}
						if(counter>0)
						{
						if((num_of_packets)>0)
						{
						chk=(num_of_packets+1);
						if(chk!=0)
						{
						chk--;
						//printf("In function...");
						//int point=0;
						if(fgets(input,sizeof(input),fp)!=NULL)
						{
						//printf("\nInput line = %s\n", input);						
						sscanf(input,"%lf%d%lf",&packet_inter_arrival_time,&tokens_reqd,&time_service);
						lambda=(1/packet_inter_arrival_time);
						mu=(1/time_service);
						
						//printf("number to arrive%d\n",num_of_packets);
						//read_file_input=0;
						}	
						//printf("time enter%lf tokens reqd%d time service%lf\n",packet_inter_arrival_time,tokens_reqd,time_service);
						}
						//return fp;
						}
						}
						}
						else
						{
						//printf("only one line present in input\n");
						}
						//comand_i++;
						//argc--;
						//argc--;
						}
						return NULL;
}
